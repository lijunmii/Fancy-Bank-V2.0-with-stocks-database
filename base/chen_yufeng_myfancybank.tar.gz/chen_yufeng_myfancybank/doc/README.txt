run main method in Test.java to test all code.
