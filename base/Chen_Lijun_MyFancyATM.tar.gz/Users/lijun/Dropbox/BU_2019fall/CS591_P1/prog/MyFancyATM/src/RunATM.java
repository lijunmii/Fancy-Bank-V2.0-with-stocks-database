public class RunATM {
    public static void main(String[] args) {
        ATM myATM = new ATM();
    }
}
