import java.util.List;

public class BankManager {

    private String pwd;
    private BankTransactionHistory transactionHistory;

    public BankManager(String pwd) {
        this.pwd = pwd;
        transactionHistory = new BankTransactionHistory();
    }

    public String getPwd() {
        return pwd;
    }

    public List<String> getTransactionHistory() {
        return transactionHistory.getHistory();
    }

    public void setTransactionHistory(BankTransactionHistory transactionHistory) {
        this.transactionHistory = transactionHistory;
    }

    public void updataTransactionHistory(String newTransaction) {
        this.transactionHistory.addHistory(newTransaction);
    }

    public void clearTransactionHistory() {
        this.transactionHistory.clearHistory();
    }
}