import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class ATM {

    private final double SAVING_INTEREST_RATE = 0.05;
    private final double LOAN_INTEREST_RATE = 0.1;
    private final int ACTION_FEE = 30;
    private final double SAVING_INTEREST_THRESHOLD = 100000.0;

    private List<BankCustomer> customerList;
    private BankManager manager;

    private JFrame welcomeFrame;

    public ATM() {

        welcomeFrame = new WelcomeFrame();
        // Initialize frame information
        welcomeFrame.setTitle( "Welcome to my Fancy ATM" );
        welcomeFrame.setSize( 500, 500 );
        welcomeFrame.setLocation( 200, 200 );
        welcomeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        welcomeFrame.setVisible(true);

        customerList = new ArrayList<>();
        BankCustomer customer1 = new BankCustomer("123@mimi.com", "123");
        BankCustomer customer2 = new BankCustomer("111@haha.com", "111");
        customer1.addBankAccount(new BankAccount("11111", "SavingAccount"));
        customer1.addBankAccount(new BankAccount("22222", "CheckingAccount"));
        customer2.addBankAccount(new BankAccount("33333", "SavingAccount"));
        customer2.addBankAccount(new BankAccount("44444", "CheckingAccount"));
        customerList.add(customer1);
        customerList.add(customer2);

        manager = new BankManager("12345");
    }

    class WelcomeFrame extends JFrame {

        private JPanel welcomePanel;
        private JLabel welcomeMsg;
        private JButton isNewCustomer, isOldCustomer, isManager;

        public WelcomeFrame() throws HeadlessException {

            welcomePanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome to Lijun's Fancy ATM.");
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.anchor = GridBagConstraints.LINE_START;
            welcomePanel.add(welcomeMsg, constraint);

            isNewCustomer = new JButton("I'm a new customer");
            isNewCustomer.addActionListener(new NewCustomerListener());
            constraint.gridx = 0;
            constraint.gridy = 1;
            welcomePanel.add(isNewCustomer, constraint);

            isOldCustomer = new JButton("I'm an old customer");
            isOldCustomer.addActionListener(new OldCustomerListener());
            constraint.gridx = 0;
            constraint.gridy = 3;
            welcomePanel.add(isOldCustomer, constraint);

            isManager = new JButton("I'm a bank manager");
            isManager.addActionListener(new ManagerListener());
            constraint.gridx = 0;
            constraint.gridy = 5;
            welcomePanel.add(isManager, constraint);

            add(welcomePanel);

            setVisible(true);
        }
    }

    class CustomerSignUp extends JFrame {

        private JPanel signUpPanel;
        private JLabel instruction, email, password, error;
        private JTextField emailTF;
        private JPasswordField pwdPF;
        private JButton signUp, backToWelcomePage;

        public CustomerSignUp() throws HeadlessException {

            signUpPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            instruction = new JLabel("Please enter your email address and password to sign up.");
            constraint.gridwidth = 40;
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.anchor = GridBagConstraints.LINE_START;
            signUpPanel.add(instruction, constraint);

            email = new JLabel("Email:");
            constraint.gridwidth = 1;
            constraint.gridx = 0;
            constraint.gridy = 1;
            constraint.anchor = GridBagConstraints.LINE_START;
            signUpPanel.add(email, constraint);

            emailTF = new JTextField(30);
            constraint.gridwidth = 2;
            constraint.gridx = 0;
            constraint.gridy = 2;
            signUpPanel.add(emailTF, constraint);

            password = new JLabel("Passowrd:");
            constraint.gridwidth = 1;
            constraint.gridx = 0;
            constraint.gridy = 3;
            signUpPanel.add(password, constraint);

            pwdPF = new JPasswordField(30);
            constraint.gridwidth = 2;
            constraint.gridx = 0;
            constraint.gridy = 4;
            signUpPanel.add(pwdPF, constraint);

            signUp = new JButton("Sign Up!");
            constraint.gridx = 0;
            constraint.gridy = 5;
            signUpPanel.add(signUp, constraint);
            signUp.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String emailInput = emailTF.getText();
                    String pwdInput = new String(pwdPF.getPassword());

                    if (isEmailUnique(emailInput)) {
                        BankCustomer customer = new BankCustomer(emailInput, pwdInput);
                        customerList.add(customer);

                        CustomerFrame customerFrame = new CustomerFrame(customer);
                        customerFrame.setTitle( "Welcome to my Fancy ATM" );
                        customerFrame.setSize( 500, 500 );
                        customerFrame.setLocation( 200, 200 );
                        customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        customerFrame.setVisible(true);
                        setVisible(false);
                    } else {
                        error.setVisible(true);
                    }
                }
            });

            backToWelcomePage = new JButton("Back to welcome page");
            constraint.gridy = 6;
            constraint.gridwidth = 2;
            signUpPanel.add(backToWelcomePage,constraint);
            backToWelcomePage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    WelcomeFrame welcomePage = new WelcomeFrame();

                    welcomePage.setTitle( "Welcome to my Fancy ATM" );
                    welcomePage.setSize( 500, 500 );
                    welcomePage.setLocation( 200, 200 );
                    welcomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    welcomePage.setVisible(true);
                    setVisible(false);
                }
            });

            error = new JLabel("This email has already signed up.");
            constraint.gridx = 0;
            constraint.gridy = 7;
            constraint.gridwidth = 2;
            signUpPanel.add(error, constraint);
            error.setVisible(false);

            add(signUpPanel);
        }
    }

    class CustomerLogIn extends JFrame {

        private JPanel logInPanel;
        private JLabel instruction, email, password, error;
        private JTextField emailTF;
        private JPasswordField pwdPF;
        private JButton logIn, backToWelcomePage;

        public CustomerLogIn() throws HeadlessException {

            logInPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            instruction = new JLabel("Please enter your email address and password to log in.");
            constraint.gridwidth = 40;
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.anchor = GridBagConstraints.LINE_START;
            logInPanel.add(instruction, constraint);

            email = new JLabel("Email:");
            constraint.gridwidth = 1;
            constraint.gridx = 0;
            constraint.gridy = 1;
            constraint.anchor = GridBagConstraints.LINE_START;
            logInPanel.add(email, constraint);

            emailTF = new JTextField(30);
            constraint.gridwidth = 2;
            constraint.gridx = 0;
            constraint.gridy = 2;
            logInPanel.add(emailTF, constraint);

            password = new JLabel("Passowrd:");
            constraint.gridwidth = 1;
            constraint.gridx = 0;
            constraint.gridy = 3;
            logInPanel.add(password, constraint);

            pwdPF = new JPasswordField(30);
            constraint.gridwidth = 2;
            constraint.gridx = 0;
            constraint.gridy = 4;
            logInPanel.add(pwdPF, constraint);

            logIn = new JButton("Log in!");
            constraint.gridx = 0;
            constraint.gridy = 5;
            logInPanel.add(logIn, constraint);
            logIn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String emailInput = emailTF.getText();
                    String pwdInput = new String(pwdPF.getPassword());
                    if (authenticateLogIn(emailInput, pwdInput)) {
                        CustomerFrame customerFrame = new CustomerFrame(findCustomer(emailInput));

                        customerFrame.setTitle( "Welcome to my Fancy ATM" );
                        customerFrame.setSize( 500, 500 );
                        customerFrame.setLocation( 200, 200 );
                        customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        customerFrame.setVisible(true);
                        setVisible(false);
                    } else {
                        error.setVisible(true);
                    }
                }
            });

            backToWelcomePage = new JButton("Back to welcome page");
            constraint.gridy = 6;
            constraint.gridwidth = 2;
            logInPanel.add(backToWelcomePage,constraint);
            backToWelcomePage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    WelcomeFrame welcomePage = new WelcomeFrame();

                    welcomePage.setTitle( "Welcome to my Fancy ATM" );
                    welcomePage.setSize( 500, 500 );
                    welcomePage.setLocation( 200, 200 );
                    welcomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    welcomePage.setVisible(true);
                    setVisible(false);
                }
            });

            error = new JLabel("The supplied email address or password is incorrect.");
            constraint.gridx = 0;
            constraint.gridy = 7;
            logInPanel.add(error,constraint);
            error.setVisible(false);

            add(logInPanel);
        }
    }

    class CustomerFrame extends JFrame {

        private BankCustomer customer;
        private JPanel customerPanel;
        private JLabel welcomeMsg;
        private JButton createAccount, closeAccount, saveMoney, transferMoney, withdrawMoney, loanMoney, returnLoan;
        private JButton viewTransaction, viewBalance, signOut;
        private int yGrid;

        public CustomerFrame(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;
            yGrid = 0;

            customerPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridy = yGrid++;
            customerPanel.add(welcomeMsg, constraint);

            createAccount = new JButton("Create an account");
            constraint.gridy = yGrid++;
            constraint.fill = GridBagConstraints.HORIZONTAL;
            customerPanel.add(createAccount, constraint);
            createAccount.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerCreateAccount createAccount = new CustomerCreateAccount(customer);

                    createAccount.setTitle( "Welcome to my Fancy ATM" );
                    createAccount.setSize( 500, 500 );
                    createAccount.setLocation( 200, 200 );
                    createAccount.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    createAccount.setVisible(true);
                    setVisible(false);
                }
            });

            closeAccount = new JButton("Close an account");
            constraint.gridy = yGrid++;
            customerPanel.add(closeAccount, constraint);
            closeAccount.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerCloseAccount closeAccount = new CustomerCloseAccount(customer);

                    closeAccount.setTitle( "Welcome to my Fancy ATM" );
                    closeAccount.setSize( 500, 500 );
                    closeAccount.setLocation( 200, 200 );
                    closeAccount.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    closeAccount.setVisible(true);
                    setVisible(false);
                }
            });

            saveMoney = new JButton("Save money");
            constraint.gridy = yGrid++;
            customerPanel.add(saveMoney, constraint);
            saveMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerSaveMoney saveMoney = new CustomerSaveMoney(customer);

                    saveMoney.setTitle( "Welcome to my Fancy ATM" );
                    saveMoney.setSize( 500, 500 );
                    saveMoney.setLocation( 200, 200 );
                    saveMoney.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    saveMoney.setVisible(true);
                    setVisible(false);
                }
            });

            withdrawMoney = new JButton("Withdraw money");
            constraint.gridy = yGrid++;
            customerPanel.add(withdrawMoney, constraint);
            withdrawMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerWithdrawMoney withdrawMoney = new CustomerWithdrawMoney(customer);

                    withdrawMoney.setTitle( "Welcome to my Fancy ATM" );
                    withdrawMoney.setSize( 500, 500 );
                    withdrawMoney.setLocation( 200, 200 );
                    withdrawMoney.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    withdrawMoney.setVisible(true);
                    setVisible(false);
                }
            });

            loanMoney = new JButton("Loan money");
            constraint.gridy = yGrid++;
            customerPanel.add(loanMoney, constraint);
            loanMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerLoanMoney customerLoanMoney = new CustomerLoanMoney(customer);

                    customerLoanMoney.setTitle( "Welcome to my Fancy ATM" );
                    customerLoanMoney.setSize( 500, 500 );
                    customerLoanMoney.setLocation( 200, 200 );
                    customerLoanMoney.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerLoanMoney.setVisible(true);
                    setVisible(false);
                }
            });

            returnLoan = new JButton("Return Loan");
            constraint.gridy = yGrid++;
            customerPanel.add(returnLoan, constraint);
            returnLoan.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerReturnLoan customerReturnLoan = new CustomerReturnLoan(customer);

                    customerReturnLoan.setTitle( "Welcome to my Fancy ATM" );
                    customerReturnLoan.setSize( 500, 500 );
                    customerReturnLoan.setLocation( 200, 200 );
                    customerReturnLoan.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerReturnLoan.setVisible(true);
                    setVisible(false);
                }
            });

            transferMoney = new JButton("Transfer money");
            constraint.gridy = yGrid++;
            customerPanel.add(transferMoney, constraint);
            transferMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerTransferMoney customerTransferMoney = new CustomerTransferMoney(customer);

                    customerTransferMoney.setTitle( "Welcome to my Fancy ATM" );
                    customerTransferMoney.setSize( 500, 500 );
                    customerTransferMoney.setLocation( 200, 200 );
                    customerTransferMoney.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerTransferMoney.setVisible(true);
                    setVisible(false);
                }
            });

            viewTransaction = new JButton("View your past transaction");
            constraint.gridy = yGrid++;
            customerPanel.add(viewTransaction, constraint);
            viewTransaction.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerViewTransactionHistory viewTransactionHistory = new CustomerViewTransactionHistory(customer);

                    viewTransactionHistory.setTitle( "Welcome to my Fancy ATM" );
                    viewTransactionHistory.setSize( 500, 500 );
                    viewTransactionHistory.setLocation( 200, 200 );
                    viewTransactionHistory.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    viewTransactionHistory.setVisible(true);
                    setVisible(false);
                }
            });

            viewBalance = new JButton("View your balance");
            constraint.gridy = yGrid++;
            customerPanel.add(viewBalance, constraint);
            viewBalance.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerBalance customerBalance = new CustomerBalance(customer);

                    customerBalance.setTitle( "Welcome to my Fancy ATM" );
                    customerBalance.setSize( 500, 500 );
                    customerBalance.setLocation( 200, 200 );
                    customerBalance.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerBalance.setVisible(true);
                    setVisible(false);
                }
            });

            signOut = new JButton("Sign out and back to welcome page");
            constraint.gridy = yGrid++;
            customerPanel.add(signOut, constraint);
            signOut.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    WelcomeFrame welcomePage = new WelcomeFrame();

                    welcomePage.setTitle( "Welcome to my Fancy ATM" );
                    welcomePage.setSize( 500, 500 );
                    welcomePage.setLocation( 200, 200 );
                    welcomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    welcomePage.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerPanel);
        }
    }

    class CustomerCreateAccount extends JFrame {

        private BankCustomer customer;
        private JPanel customerCreateAccountPanel;
        private JLabel welcomeMsg, accountType, successChecking, successSaving;
        private ButtonGroup accountGroup;
        private JRadioButton savingAccount, checkingAccount;
        private JButton create, backToCustomerMainPage;

        public CustomerCreateAccount(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;

            customerCreateAccountPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.gridwidth = 2;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerCreateAccountPanel.add(welcomeMsg, constraint);

            // user select which type of account to create
            accountType = new JLabel("Please select which type of account you want to create.");
            constraint.gridx = 0;
            constraint.gridy = 1;
            constraint.gridwidth = 2;
            customerCreateAccountPanel.add(accountType, constraint);

            accountGroup = new ButtonGroup();

            savingAccount = new JRadioButton("Saving Account");
            constraint.gridx = 0;
            constraint.gridy = 2;
            constraint.gridwidth = 1;
            accountGroup.add(savingAccount);
            customerCreateAccountPanel.add(savingAccount, constraint);

            checkingAccount = new JRadioButton("Checking Account");
            constraint.gridx = 1;
            constraint.gridy = 2;
            accountGroup.add(checkingAccount);
            customerCreateAccountPanel.add(checkingAccount, constraint);

            create = new JButton("Create account!");
            constraint.gridx = 0;
            constraint.gridy = 3;
            customerCreateAccountPanel.add(create, constraint);
            create.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    boolean isValid = false;
                    String accountNum = "";
                    while(!isValid) {
                        accountNum = createRandomAccountNum();
                        isValid = isUniqueAccountNum(accountNum);
                    }

                    if (savingAccount.isSelected()) {
                        BankAccount account = new BankAccount(accountNum, "SavingAccount");
                        customer.addBankAccount(account);

                        account.updateDeposit("Dollor", -1*ACTION_FEE);

                        successSaving.setVisible(true);
                        successChecking.setVisible(false);
                    } else {
                        BankAccount account = new BankAccount(accountNum, "CheckingAccount");
                        customer.addBankAccount(account);
                        successChecking.setVisible(true);
                        successSaving.setVisible(false);
                    }
                }
            });

            successSaving = new JLabel("You've successfully created a saving account");
            successChecking = new JLabel("You've successfully created a checking account");
            constraint.gridx = 0;
            constraint.gridy = 5;
            constraint.gridwidth = 2;
            customerCreateAccountPanel.add(successSaving, constraint);
            successSaving.setVisible(false);
            customerCreateAccountPanel.add(successChecking, constraint);
            successChecking.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridx = 0;
            constraint.gridy = 4;
            constraint.gridwidth = 1;
            customerCreateAccountPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerCreateAccountPanel);
        }
    }

    class CustomerCloseAccount extends JFrame {

        private BankCustomer customer;
        private JPanel customerCloseAccountPanel;
        private JLabel welcomeMsg, accountSelection, deleteChecking, deleteSaving, fail;
        private JButton create, backToCustomerMainPage;
        private JComboBox accountBox;

        public CustomerCloseAccount(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;

            customerCloseAccountPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.gridwidth = 2;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerCloseAccountPanel.add(welcomeMsg, constraint);

            // select account
            accountSelection = new JLabel("Select an account you want to close");
            constraint.gridx = 0;
            constraint.gridy = 1;
            customerCloseAccountPanel.add(accountSelection, constraint);

            String[] accounts = getAccountTypeAndNum(customer.getBankAccountList());
            accountBox = new JComboBox(accounts);
            constraint.gridx = 0;
            constraint.gridy = 2;
            constraint.gridwidth = 2;
            customerCloseAccountPanel.add(accountBox, constraint);


            create = new JButton("Close account!");
            constraint.gridx = 0;
            constraint.gridy = 3;
            customerCloseAccountPanel.add(create, constraint);
            create.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedAccountType = selectedAccount[0];
                    String selectedaccountNum = selectedAccount[1];

                    BankAccount account = customer.getBankAccount(selectedaccountNum);

                    if (customer.isAccountEmpty(account)) {

                    }

                    customer.removeBankAccount(customer.getBankAccount(selectedaccountNum));

                    if (selectedAccountType.equals("SavingAccount")) {
                        deleteSaving.setVisible(true);
                        deleteChecking.setVisible(false);
                    } else {
                        deleteSaving.setVisible(false);
                        deleteChecking.setVisible(true);
                    }
                }
            });

            deleteSaving = new JLabel("You've successfully closed a saving account");
            deleteChecking = new JLabel("You've successfully closed a checking account");
            fail = new JLabel("Sorry, you don't have enough money to close an account.");

            constraint.gridx = 0;
            constraint.gridy = 5;
            constraint.gridwidth = 2;
            customerCloseAccountPanel.add(deleteSaving, constraint);
            deleteSaving.setVisible(false);
            customerCloseAccountPanel.add(deleteChecking, constraint);
            deleteChecking.setVisible(false);
            customerCloseAccountPanel.add(fail, constraint);
            fail.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridx = 0;
            constraint.gridy = 4;
            constraint.gridwidth = 1;
            customerCloseAccountPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerCloseAccountPanel);
        }
    }

    class CustomerSaveMoney extends JFrame {

        private BankCustomer customer;
        private JPanel customerSaveMoneyPanel;
        private JLabel welcomeMsg, accountSelection, currencyType, askInputAmount, error, success;
        private JComboBox accountBox;
        private ButtonGroup currencyGroup;
        private JRadioButton Dollor, Yuan, Pound;
        private JTextField amount;
        private JButton saveMoney, backToCustomerMainPage;

        public CustomerSaveMoney(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;

            customerSaveMoneyPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerSaveMoneyPanel.add(welcomeMsg, constraint);

            // select account
            accountSelection = new JLabel("Select an account to save your money");
            constraint.gridx = 0;
            constraint.gridy = 1;
            customerSaveMoneyPanel.add(accountSelection, constraint);

            String[] accounts = getAccountTypeAndNum(customer.getBankAccountList());
            accountBox = new JComboBox(accounts);
            constraint.gridx = 0;
            constraint.gridy = 2;
            constraint.gridwidth = 2;
            customerSaveMoneyPanel.add(accountBox, constraint);

            // select currency
            currencyType = new JLabel("Please choose which currency you want to save");
            constraint.gridx = 0;
            constraint.gridy = 3;
            constraint.gridwidth = 3;
            customerSaveMoneyPanel.add(currencyType, constraint);

            currencyGroup = new ButtonGroup();
            Dollor = new JRadioButton("Dollar");
            constraint.gridx = 0;
            constraint.gridy = 4;
            constraint.gridwidth = 1;
            customerSaveMoneyPanel.add(Dollor, constraint);
            currencyGroup.add(Dollor);

            Yuan = new JRadioButton("Yuan");
            constraint.gridx = 0;
            constraint.gridy = 5;
            currencyGroup.add(Yuan);
            customerSaveMoneyPanel.add(Yuan, constraint);

            Pound = new JRadioButton("Pound");
            constraint.gridx = 0;
            constraint.gridy = 6;
            currencyGroup.add(Pound);
            customerSaveMoneyPanel.add(Pound, constraint);

            // type in amount
            askInputAmount = new JLabel("Please input the amount you want to save:");
            constraint.gridx = 0;
            constraint.gridy = 7;
            constraint.gridwidth = 3;
            customerSaveMoneyPanel.add(askInputAmount, constraint);

            amount = new JTextField(20);
            constraint.gridx = 0;
            constraint.gridy = 8;
            customerSaveMoneyPanel.add(amount, constraint);

            saveMoney = new JButton("Save money!");
            constraint.gridx = 0;
            constraint.gridy = 9;
            constraint.gridwidth = 3;
            customerSaveMoneyPanel.add(saveMoney, constraint);
            saveMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedaccountNum = selectedAccount[1];

                    String selectedCurrency;
                    if (!(Dollor.isSelected() || Yuan.isSelected() || Pound.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        return;
                    } else if (Dollor.isSelected()) selectedCurrency = "Dollor";
                    else if (Yuan.isSelected()) selectedCurrency = "Yuan";
                    else selectedCurrency = "Pound";
                    String inputAmount = amount.getText();

                    if (isValidInputAmount(inputAmount)) {

                        customer.updateBankAccountDeposit(customer.getBankAccount(selectedaccountNum), selectedCurrency, Double.parseDouble(inputAmount));

                        success.setVisible(true);
                        error.setVisible(false);
                    } else {
                        error.setVisible(true);
                        success.setVisible(false);
                    }
                }
            });

            error = new JLabel("Invalid input.");
            constraint.gridx = 0;
            constraint.gridy = 10;
            constraint.gridwidth = 3;
            customerSaveMoneyPanel.add(error, constraint);
            error.setVisible(false);

            success = new JLabel("You've sucessfully saved you money");
            constraint.gridx = 0;
            constraint.gridy = 10;
            constraint.gridwidth = 3;
            customerSaveMoneyPanel.add(success, constraint);
            success.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridx = 0;
            constraint.gridy = 11;
            constraint.gridwidth = 1;
            customerSaveMoneyPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerSaveMoneyPanel);
        }
    }

    class CustomerWithdrawMoney extends JFrame {

        private BankCustomer customer;
        private JPanel customerWithdrawMoneyPanel;
        private JLabel welcomeMsg, accountSelection, currencyType, askInputAmount, error, success;
        private JComboBox accountBox;
        private ButtonGroup currencyGroup;
        private JRadioButton USD, Yuan, UKP;
        private JTextField amount;
        private JButton saveMoney, backToCustomerMainPage;

        public CustomerWithdrawMoney(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;

            customerWithdrawMoneyPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridx = 0;
            constraint.gridy = 0;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerWithdrawMoneyPanel.add(welcomeMsg, constraint);

            // select account
            accountSelection = new JLabel("Select an account to withdraw your money");
            constraint.gridx = 0;
            constraint.gridy = 1;
            customerWithdrawMoneyPanel.add(accountSelection, constraint);

            String[] accounts = getAccountTypeAndNum(customer.getBankAccountList());
            accountBox = new JComboBox(accounts);
            constraint.gridx = 0;
            constraint.gridy = 2;
            constraint.gridwidth = 2;
            customerWithdrawMoneyPanel.add(accountBox, constraint);

            // select currency
            currencyType = new JLabel("Please choose which currency you want to withdraw");
            constraint.gridx = 0;
            constraint.gridy = 3;
            constraint.gridwidth = 3;
            customerWithdrawMoneyPanel.add(currencyType, constraint);

            currencyGroup = new ButtonGroup();
            USD = new JRadioButton("Dollar");
            constraint.gridx = 0;
            constraint.gridy = 4;
            constraint.gridwidth = 1;
            customerWithdrawMoneyPanel.add(USD, constraint);
            currencyGroup.add(USD);

            Yuan = new JRadioButton("Yuan");
            constraint.gridx = 0;
            constraint.gridy = 5;
            currencyGroup.add(Yuan);
            customerWithdrawMoneyPanel.add(Yuan, constraint);

            UKP = new JRadioButton("Pound");
            constraint.gridx = 0;
            constraint.gridy = 6;
            currencyGroup.add(UKP);
            customerWithdrawMoneyPanel.add(UKP, constraint);

            // type in amount
            askInputAmount = new JLabel("Please input the amount you want to withdraw:");
            constraint.gridx = 0;
            constraint.gridy = 7;
            constraint.gridwidth = 3;
            customerWithdrawMoneyPanel.add(askInputAmount, constraint);

            amount = new JTextField(20);
            constraint.gridx = 0;
            constraint.gridy = 8;
            customerWithdrawMoneyPanel.add(amount, constraint);

            saveMoney = new JButton("Withdraw money!");
            constraint.gridx = 0;
            constraint.gridy = 9;
            constraint.gridwidth = 3;
            customerWithdrawMoneyPanel.add(saveMoney, constraint);
            saveMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedAccountType = selectedAccount[0];
                    String selectedaccountNum = selectedAccount[1];

                    String selectedCurrency;
                    if (!(USD.isSelected() || Yuan.isSelected() || UKP.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        return;
                    } else if (USD.isSelected()) selectedCurrency = "Dollor";
                    else if (Yuan.isSelected()) selectedCurrency = "Yuan";
                    else selectedCurrency = "Pound";
                    String inputAmount = amount.getText();

                    double currentBalance = customer.getBankAccountDepositCurrencyBalance(customer.getBankAccount(selectedaccountNum), selectedCurrency);
                    if (isValidInputAmount(inputAmount) && Double.parseDouble(inputAmount) + ACTION_FEE < currentBalance) {

                        customer.updateBankAccountDeposit(customer.getBankAccount(selectedaccountNum), selectedCurrency, -1*Double.parseDouble(inputAmount)-ACTION_FEE);

                        success.setVisible(true);
                        error.setVisible(false);
                    } else {
                        error.setVisible(true);
                        success.setVisible(false);
                    }
                }
            });

            error = new JLabel("Invalid input.");
            constraint.gridx = 0;
            constraint.gridy = 10;
            constraint.gridwidth = 3;
            customerWithdrawMoneyPanel.add(error, constraint);
            error.setVisible(false);

            success = new JLabel("You've sucessfully withdraw you money");
            constraint.gridx = 0;
            constraint.gridy = 10;
            constraint.gridwidth = 3;
            customerWithdrawMoneyPanel.add(success, constraint);
            success.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridx = 0;
            constraint.gridy = 11;
            constraint.gridwidth = 1;
            customerWithdrawMoneyPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerWithdrawMoneyPanel);
        }
    }

    class CustomerLoanMoney extends JFrame {

        private BankCustomer customer;
        private JPanel customerLoanMoneyPanel;
        private JLabel welcomeMsg, askCollateral, accountSelection, currencyType, askInputAmount, error, success, fail;
        private JButton loanMoney, backToCustomerMainPage;
        private JComboBox accountBox;
        private ButtonGroup currencyGroup, collateralGroup;
        private JRadioButton USD, Yuan, UKP, haveCollateral, noCollateral;
        private JTextField amount;
        private int yGrid;

        public CustomerLoanMoney(BankCustomer bankCustomer) throws HeadlessException {

            customer = bankCustomer;
            yGrid = 0;

            customerLoanMoneyPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridy = yGrid++;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerLoanMoneyPanel.add(welcomeMsg, constraint);

            // ask if have collateral
            askCollateral = new JLabel("Do you have collateral to loan money?");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(askCollateral, constraint);

            collateralGroup = new ButtonGroup();
            haveCollateral = new JRadioButton("I have collateral.");
            constraint.gridy = yGrid++;
            collateralGroup.add(haveCollateral);
            customerLoanMoneyPanel.add(haveCollateral, constraint);

            noCollateral = new JRadioButton("I don't have collateral.");
            constraint.gridy = yGrid++;
            collateralGroup.add(noCollateral);
            customerLoanMoneyPanel.add(noCollateral, constraint);

            // select account
            accountSelection = new JLabel("Select an account to loan your money");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(accountSelection, constraint);

            String[] accounts = getAccountTypeAndNum(customer.getBankAccountList());
            accountBox = new JComboBox(accounts);
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(accountBox, constraint);

            // select currency
            currencyType = new JLabel("Please choose which currency you want to loan");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(currencyType, constraint);

            currencyGroup = new ButtonGroup();
            USD = new JRadioButton("Dollar");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(USD, constraint);
            currencyGroup.add(USD);

            Yuan = new JRadioButton("Yuan");
            constraint.gridy = yGrid++;
            currencyGroup.add(Yuan);
            customerLoanMoneyPanel.add(Yuan, constraint);

            UKP = new JRadioButton("Pound");
            constraint.gridy = yGrid++;
            currencyGroup.add(UKP);
            customerLoanMoneyPanel.add(UKP, constraint);

            // type in amount
            askInputAmount = new JLabel("Please input the amount you want to loan:");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(askInputAmount, constraint);

            amount = new JTextField(20);
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(amount, constraint);

            loanMoney = new JButton("Loan money!");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(loanMoney, constraint);
            loanMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedAccountType = selectedAccount[0];
                    String selectedaccountNum = selectedAccount[1];
                    String selectedCurrency = "";
                    String inputAmount = amount.getText();

                    if (!(haveCollateral.isSelected() || noCollateral.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                        return;
                    } else if (!(USD.isSelected() || Yuan.isSelected() || UKP.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                        return;
                    } else if (!isValidInputAmount(inputAmount)) {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                        return;
                    } else if (noCollateral.isSelected()) {
                        fail.setVisible(true);
                        error.setVisible(false);
                        success.setVisible(false);
                        return;
                    }

                    if (USD.isSelected()) selectedCurrency = "Dollor";
                    else if (Yuan.isSelected()) selectedCurrency = "Yuan";
                    else selectedCurrency = "Pound";

                    if (isValidInputAmount(inputAmount)) {
                        customer.updateBankAccountLoan(customer.getBankAccount(selectedaccountNum), selectedCurrency, Double.parseDouble(inputAmount));

                        success.setVisible(true);
                        error.setVisible(false);
                        fail.setVisible(false);
                    } else {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                    }
                }
            });

            fail = new JLabel("Sorry, you don't have collateral, so you cannot loan money.");
            constraint.gridy = yGrid;
            customerLoanMoneyPanel.add(fail, constraint);
            fail.setVisible(false);

            error = new JLabel("Invalid input.");
            constraint.gridy = yGrid;
            customerLoanMoneyPanel.add(error, constraint);
            error.setVisible(false);

            success = new JLabel("You've sucessfully loaned money");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(success, constraint);
            success.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridy = yGrid++;
            customerLoanMoneyPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerLoanMoneyPanel);
        }
    }

    class CustomerReturnLoan extends JFrame {

        private BankCustomer customer;
        private JPanel customerReturnLoanPanel;
        private JLabel welcomeMsg, accountSelection, currencyType, askInputAmount, error, success, fail;
        private JButton loanMoney, backToCustomerMainPage;
        private JComboBox accountBox;
        private ButtonGroup currencyGroup;
        private JRadioButton USD, Yuan, UKP;
        private JTextField amount;
        private int yGrid;

        public CustomerReturnLoan(BankCustomer bankCustomer) throws HeadlessException {

            customer = bankCustomer;
            yGrid = 0;

            customerReturnLoanPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridy = yGrid++;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerReturnLoanPanel.add(welcomeMsg, constraint);

            // select account
            accountSelection = new JLabel("Select an account that you to return your loan");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(accountSelection, constraint);

            String[] accounts = getAccountTypeAndNum(customer.getBankAccountOnLoan());
            accountBox = new JComboBox(accounts);
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(accountBox, constraint);

            // select currency
            currencyType = new JLabel("Please choose which currency you want to return");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(currencyType, constraint);

            currencyGroup = new ButtonGroup();
            USD = new JRadioButton("Dollar");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(USD, constraint);
            currencyGroup.add(USD);

            Yuan = new JRadioButton("Yuan");
            constraint.gridy = yGrid++;
            currencyGroup.add(Yuan);
            customerReturnLoanPanel.add(Yuan, constraint);

            UKP = new JRadioButton("Pound");
            constraint.gridy = yGrid++;
            currencyGroup.add(UKP);
            customerReturnLoanPanel.add(UKP, constraint);

            // type in amount
            askInputAmount = new JLabel("Please input the amount you want to return:");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(askInputAmount, constraint);

            amount = new JTextField(20);
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(amount, constraint);

            loanMoney = new JButton("Return money!");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(loanMoney, constraint);
            loanMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedAccountType = selectedAccount[0];
                    String selectedaccountNum = selectedAccount[1];
                    String selectedCurrency;
                    String inputAmount = amount.getText();

                    if (!(USD.isSelected() || Yuan.isSelected() || UKP.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                        return;
                    } else if (!isValidInputAmount(inputAmount)) {
                        error.setVisible(true);
                        success.setVisible(false);
                        fail.setVisible(false);
                        return;
                    }

                    if (USD.isSelected()) selectedCurrency = "Dollor";
                    else if (Yuan.isSelected()) selectedCurrency = "Yuan";
                    else selectedCurrency = "Pound";

                    double loanAmount = customer.getBankAccountLoanCurrencyBalance(customer.getBankAccount(selectedaccountNum), selectedCurrency);
                    if (loanAmount == 0.0) {
                        fail.setVisible(true);
                        error.setVisible(false);
                        success.setVisible(false);
                        return;
                    } else if (Double.parseDouble(inputAmount) > loanAmount) {
                        customer.updateBankAccountLoan(customer.getBankAccount(selectedaccountNum), selectedCurrency, -1*loanAmount);
                        customer.updateBankAccountDeposit(customer.getBankAccount(selectedaccountNum), selectedCurrency, Double.parseDouble(inputAmount) - loanAmount);

                        success.setVisible(true);
                        error.setVisible(false);
                        fail.setVisible(false);
                    } else {
                        customer.updateBankAccountLoan(customer.getBankAccount(selectedaccountNum), selectedCurrency, -1*Double.parseDouble(inputAmount));

                        success.setVisible(true);
                        error.setVisible(false);
                        fail.setVisible(false);
                    }
                }
            });

            fail = new JLabel("You don't have loan on this account or in this currency.");
            constraint.gridy = yGrid;
            customerReturnLoanPanel.add(fail, constraint);
            fail.setVisible(false);

            error = new JLabel("Invalid input.");
            constraint.gridy = yGrid;
            customerReturnLoanPanel.add(error, constraint);
            error.setVisible(false);

            success = new JLabel("You've sucessfully returned loaned money");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(success, constraint);
            success.setVisible(false);

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridy = yGrid++;
            customerReturnLoanPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle("Welcome to my Fancy ATM");
                    customerFrame.setSize(500, 500);
                    customerFrame.setLocation(200, 200);
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerReturnLoanPanel);
        }
    }

    class CustomerTransferMoney extends JFrame {

        private BankCustomer customer;
        private JPanel customerTransferMoneyPanel;
        private JLabel welcomeMsg, accountSelection, currencyType, askInputAmount, selectFriendAccount, error, success;
        private JComboBox accountBox, avaliableBox;
        private ButtonGroup currencyGroup;
        private JRadioButton Dollor, Yuan, Pound;
        private JTextField amount;
        private JButton transferMoney, backToCustomerMainPage;
        private int yGrid;

        public CustomerTransferMoney(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;
            yGrid = 0;

            customerTransferMoneyPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridy = yGrid++;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerTransferMoneyPanel.add(welcomeMsg, constraint);

            // select account
            accountSelection = new JLabel("Select an account transfer money from");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(accountSelection, constraint);

            String[] accounts = getCheckingAccountList(customer.getBankAccountList());
            accountBox = new JComboBox(accounts);
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(accountBox, constraint);

            // select currency
            currencyType = new JLabel("Select a currency you want to transfer");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(currencyType, constraint);

            currencyGroup = new ButtonGroup();
            Dollor = new JRadioButton("Dollar");
            constraint.gridy = yGrid++;
            currencyGroup.add(Dollor);
            customerTransferMoneyPanel.add(Dollor, constraint);

            Yuan = new JRadioButton("Yuan");
            constraint.gridy = yGrid++;
            currencyGroup.add(Yuan);
            customerTransferMoneyPanel.add(Yuan, constraint);

            Pound = new JRadioButton("Pound");
            constraint.gridy = yGrid++;
            currencyGroup.add(Pound);
            customerTransferMoneyPanel.add(Pound, constraint);

            // type in amount
            askInputAmount = new JLabel("Please input the amount you want to transfer:");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(askInputAmount, constraint);

            amount = new JTextField(20);
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(amount, constraint);

            // select transfer to account
            selectFriendAccount = new JLabel("Select an account transfer money to");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(selectFriendAccount, constraint);

            String[] allAvaliableAccounts = getEmailAndAccountNum();
            avaliableBox = new JComboBox(allAvaliableAccounts);
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(avaliableBox, constraint);

            // transfer money button
            transferMoney = new JButton("Transfer money!");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(transferMoney, constraint);
            transferMoney.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selected = (String) accountBox.getSelectedItem();
                    String[] selectedAccount = selected.split(" ");
                    String selectedAccountType = selectedAccount[0];
                    String selectedaccountNum = selectedAccount[1];
                    String selectedCurrency = "";
                    String inputAmount = amount.getText();

                    String friendInfo = (String) avaliableBox.getSelectedItem();
                    String[] getFriend = friendInfo.split(" ");
                    String friendEmail = getFriend[0];
                    String friendAccountNum = getFriend[1];

                    if (!(Dollor.isSelected() || Yuan.isSelected() || Pound.isSelected())) {
                        error.setVisible(true);
                        success.setVisible(false);
                        return;
                    } else if (!isValidInputAmount(inputAmount)) {
                        error.setVisible(true);
                        success.setVisible(false);
                        return;
                    }

                    if (Dollor.isSelected()) selectedCurrency = "Dollor";
                    else if (Yuan.isSelected()) selectedCurrency = "Yuan";
                    else selectedCurrency = "Pound";

                    double currentBalance = customer.getBankAccountDepositCurrencyBalance(customer.getBankAccount(selectedaccountNum), selectedCurrency);
                    if (Double.parseDouble(inputAmount) + ACTION_FEE > currentBalance) {
                        error.setVisible(true);
                        success.setVisible(false);
                        return;
                    }

                    BankCustomer friend = findCustomer(friendEmail);

                    customer.updateBankAccountDeposit(customer.getBankAccount(selectedaccountNum), selectedCurrency, -1*Double.parseDouble(inputAmount)-ACTION_FEE);
                    friend.updateBankAccountDeposit(friend.getBankAccount(friendAccountNum), selectedCurrency, Double.parseDouble(friendAccountNum));
                    customer.updataTransactionHistory("Transfer " + Double.parseDouble(inputAmount) +
                            " " + selectedCurrency + " to " + friendEmail + " (Account number: " + friendAccountNum + ")");
                    friend.updataTransactionHistory("Accept transfer to " + friendAccountNum + "from " +
                            customer.getEmail() + " (Account number: " + selectedaccountNum + ")" + Double.parseDouble(inputAmount) +
                            " " + selectedCurrency);
                    manager.updataTransactionHistory(customer.getEmail() + " (Account number: " +
                            selectedaccountNum + ")" + " transfer " + Double.parseDouble(inputAmount) + " " +
                            selectedCurrency + " to " + friendEmail + " (Account number: " + friendAccountNum + ")");

                    success.setVisible(true);
                    error.setVisible(false);
                }
            });

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle("Welcome to my Fancy ATM");
                    customerFrame.setSize(500, 500);
                    customerFrame.setLocation(200, 200);
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            error = new JLabel("Invalid input.");
            constraint.gridy = yGrid;
            customerTransferMoneyPanel.add(error, constraint);
            error.setVisible(false);

            success = new JLabel("You've sucessfully transfered money");
            constraint.gridy = yGrid++;
            customerTransferMoneyPanel.add(success, constraint);
            success.setVisible(false);

            add(customerTransferMoneyPanel);
        }
    }

    class CustomerViewTransactionHistory extends JFrame {

        private BankCustomer customer;
        private JPanel customerViewTransactionHistoryPanel;
        private JLabel welcomeMsg;
        private JButton backToCustomerMainPage;
        private JScrollPane scrollPane;
        private int yGrid;

        public CustomerViewTransactionHistory(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;
            yGrid = 0;

            customerViewTransactionHistoryPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            scrollPane = new JScrollPane();
            customerViewTransactionHistoryPanel.add(scrollPane);

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridy = yGrid++;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerViewTransactionHistoryPanel.add(welcomeMsg, constraint);

            List<String> historys = customer.getTransactionHistory();

            for (String history : historys) {
                constraint.gridy = yGrid++;
                customerViewTransactionHistoryPanel.add(new JLabel(history), constraint);
            }

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridy = yGrid++;
            customerViewTransactionHistoryPanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle("Welcome to my Fancy ATM");
                    customerFrame.setSize(500, 500);
                    customerFrame.setLocation(200, 200);
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerViewTransactionHistoryPanel);
        }
    }

    class CustomerBalance extends JFrame {

        private BankCustomer customer;
        private JPanel customerBalancePanel;
        private JLabel welcomeMsg;
        private JButton backToCustomerMainPage;
        private int yGrid;

        public CustomerBalance(BankCustomer bankCustomer) throws HeadlessException {
            customer = bankCustomer;

            yGrid = 0;

            customerBalancePanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            welcomeMsg = new JLabel("Welcome " + customer.getEmail() + "!");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            constraint.gridwidth = 2;
            constraint.anchor = GridBagConstraints.LINE_START;
            customerBalancePanel.add(welcomeMsg, constraint);

            List<BankAccount> accountList = customer.getBankAccountList();

            if (accountList == null) {
                constraint.gridy = yGrid;
                customerBalancePanel.add(new JLabel("You don't have an account. Please open an account first."), constraint);
            } else {
                constraint.gridwidth = 1;
                for (BankAccount account : accountList) {



                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    customerBalancePanel.add(new JLabel("For " + account.getAccountType() + " with account number " + account.getAccountNum()), constraint);

                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    customerBalancePanel.add(new JLabel("Below is your deposit balance"), constraint);

                    HashMap<String, Double> deposit = account.getDeposit();
                    for (Map.Entry<String, Double> entry : deposit.entrySet()) {
                        constraint.gridx = 0;
                        constraint.gridy = yGrid;
                        constraint.anchor = GridBagConstraints.LINE_START;
                        customerBalancePanel.add(new JLabel(entry.getKey()), constraint);
                        constraint.gridx = 1;
                        constraint.gridy = yGrid++;
                        constraint.anchor = GridBagConstraints.CENTER;
                        customerBalancePanel.add(new JLabel(entry.getValue().toString()), constraint);
                    }

                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    customerBalancePanel.add(new JLabel("Below is your loan balance"), constraint);

                    HashMap<String, Double> loan = account.getLoan();
                    for (Map.Entry<String, Double> entry : loan.entrySet()) {
                        constraint.gridx = 0;
                        constraint.gridy = yGrid;
                        constraint.anchor = GridBagConstraints.LINE_START;
                        customerBalancePanel.add(new JLabel(entry.getKey()), constraint);
                        constraint.gridx = 1;
                        constraint.gridy = yGrid++;
                        constraint.anchor = GridBagConstraints.CENTER;
                        customerBalancePanel.add(new JLabel(entry.getValue().toString()), constraint);
                    }
                }
            }

            backToCustomerMainPage = new JButton("Back to customer main page");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            constraint.gridwidth = 2;
            customerBalancePanel.add(backToCustomerMainPage, constraint);
            backToCustomerMainPage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CustomerFrame customerFrame = new CustomerFrame(customer);

                    customerFrame.setTitle( "Welcome to my Fancy ATM" );
                    customerFrame.setSize( 500, 500 );
                    customerFrame.setLocation( 200, 200 );
                    customerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    customerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(customerBalancePanel);
        }
    }

    class ManagerLogInFrame extends JFrame {

        private JPanel managerLogInPanel;
        private JLabel fail;
        private JTextField enterPwd;
        private JButton managerLogIn;

        public ManagerLogInFrame() throws HeadlessException {

            managerLogInPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            enterPwd = new JTextField("Manager's password",15);
            managerLogInPanel.add(enterPwd, constraint);

            managerLogIn = new JButton("Manager log in");
            constraint.gridx = 1;
            constraint.gridy = 0;
            managerLogInPanel.add(managerLogIn, constraint);
            managerLogIn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String enteredPwd = enterPwd.getText();
                    if (enteredPwd.equals(manager.getPwd())) {
                        ManagerFrame managerFrame = new ManagerFrame();

                        managerFrame.setTitle( "Welcome to my Fancy ATM" );
                        managerFrame.setSize( 500, 500 );
                        managerFrame.setLocation( 200, 200 );
                        managerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        managerFrame.setVisible(true);
                        setVisible(false);
                    } else {
                        fail.setVisible(true);
                    }
                }
            });

            fail = new JLabel("Incorrect password. Try again.");
            constraint.gridy = 1;
            managerLogInPanel.add(fail, constraint);
            fail.setVisible(false);

            add(managerLogInPanel);
        }
    }

    class ManagerFrame extends JFrame {

        private JPanel managerPanel;
        private JComboBox customers;
        private JLabel controlTime, monthPassed;
        private JButton backToWelcomeFrame, goToThisCustomer, getTransactionReport, aMonthPass;
        private int yGrid;
        private GridBagConstraints constraint;

        public ManagerFrame() throws HeadlessException {

            yGrid = 0;

            managerPanel = new JPanel(new GridBagLayout());
            constraint = new GridBagConstraints();

            String[] customerEmail = getAllCustomerEmail();
            customers = new JComboBox(customerEmail);
            constraint.gridy = yGrid;
            managerPanel.add(customers, constraint);

            goToThisCustomer = new JButton("Go to this customer");
            constraint.gridx = 1;
            constraint.gridy = yGrid++;
            managerPanel.add(goToThisCustomer, constraint);
            goToThisCustomer.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    monthPassed.setVisible(false);

                    String selectedCustomer = (String) customers.getSelectedItem();
                    ManagerCheckCustomer managerCheckCustomer = new ManagerCheckCustomer(selectedCustomer);

                    managerCheckCustomer.setTitle( "Welcome to my Fancy ATM" );
                    managerCheckCustomer.setSize( 500, 500 );
                    managerCheckCustomer.setLocation( 200, 200 );
                    managerCheckCustomer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    managerCheckCustomer.setVisible(true);
                    setVisible(false);
                }
            });

            getTransactionReport = new JButton("Get updated transaction report from last time");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            constraint.gridwidth = 2;
            constraint.fill = GridBagConstraints.HORIZONTAL;
            managerPanel.add(getTransactionReport, constraint);
            getTransactionReport.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    monthPassed.setVisible(false);

                    ManagerViewTransactionReport managerViewTransactionReport = new ManagerViewTransactionReport();

                    managerViewTransactionReport.setTitle( "Welcome to my Fancy ATM" );
                    managerViewTransactionReport.setSize( 500, 500 );
                    managerViewTransactionReport.setLocation( 200, 200 );
                    managerViewTransactionReport.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    managerViewTransactionReport.setVisible(true);
                    setVisible(false);
                }
            });

            controlTime = new JLabel("Time controller: ");
            constraint.gridy = yGrid;
            constraint.gridwidth = 1;
            managerPanel.add(controlTime,constraint);

            aMonthPass = new JButton("A month has passed");
            constraint.gridx = 1;
            constraint.gridy = yGrid++;
            managerPanel.add(aMonthPass, constraint);
            aMonthPass.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    managerChargeLoanInterest();
                    managerPaySavingInterest();
                    monthPassed.setVisible(true);
                }
            });

            monthPassed = new JLabel("Customer loan and saving amount has updated.");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            constraint.gridwidth = 2;
            managerPanel.add(monthPassed, constraint);
            monthPassed.setVisible(false);

            backToWelcomeFrame = new JButton("Sign out and back to welcome page");
            constraint.gridy = yGrid++;
            managerPanel.add(backToWelcomeFrame, constraint);
            backToWelcomeFrame.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    monthPassed.setVisible(false);

                    WelcomeFrame welcomePage = new WelcomeFrame();

                    welcomePage.setTitle( "Welcome to my Fancy ATM" );
                    welcomePage.setSize( 500, 500 );
                    welcomePage.setLocation( 200, 200 );
                    welcomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    welcomePage.setVisible(true);
                    setVisible(false);
                }
            });

            add(managerPanel);
        }
    }

    class ManagerCheckCustomer extends JFrame {

        private BankCustomer customer;
        private JPanel managerCheckCustomerPanel;
        private JLabel intro;
        private JButton backToManagerFrame;
        private int yGrid;

        public ManagerCheckCustomer(String email) throws HeadlessException {

            customer = findCustomer(email);
            yGrid = 0;

            managerCheckCustomerPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            List<BankAccount> accountList = customer.getBankAccountList();

            intro = new JLabel("Customer " + email);
            constraint.gridy = yGrid++;
            managerCheckCustomerPanel.add(intro, constraint);

            if (accountList == null) {
                constraint.gridy = yGrid;
                managerCheckCustomerPanel.add(new JLabel("This customer doesn't have an account."), constraint);
            } else {
                constraint.gridwidth = 1;
                for (BankAccount account : accountList) {

                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    managerCheckCustomerPanel.add(new JLabel("For " + account.getAccountType() + " with account number " + account.getAccountNum()), constraint);

                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    managerCheckCustomerPanel.add(new JLabel("Below is deposit balance"), constraint);

                    HashMap<String, Double> deposit = account.getDeposit();
                    for (Map.Entry<String, Double> entry : deposit.entrySet()) {
                        constraint.gridx = 0;
                        constraint.gridy = yGrid;
                        constraint.anchor = GridBagConstraints.LINE_START;
                        managerCheckCustomerPanel.add(new JLabel(entry.getKey()), constraint);
                        constraint.gridx = 1;
                        constraint.gridy = yGrid++;
                        constraint.anchor = GridBagConstraints.CENTER;
                        managerCheckCustomerPanel.add(new JLabel(entry.getValue().toString()), constraint);
                    }

                    constraint.gridx = 0;
                    constraint.gridy = yGrid++;
                    constraint.anchor = GridBagConstraints.LINE_START;
                    managerCheckCustomerPanel.add(new JLabel("Below is loan balance"), constraint);

                    HashMap<String, Double> loan = account.getLoan();
                    for (Map.Entry<String, Double> entry : loan.entrySet()) {
                        constraint.gridx = 0;
                        constraint.gridy = yGrid;
                        constraint.anchor = GridBagConstraints.LINE_START;
                        managerCheckCustomerPanel.add(new JLabel(entry.getKey()), constraint);
                        constraint.gridx = 1;
                        constraint.gridy = yGrid++;
                        constraint.anchor = GridBagConstraints.CENTER;
                        managerCheckCustomerPanel.add(new JLabel(entry.getValue().toString()), constraint);
                    }
                }
            }

            backToManagerFrame = new JButton("Back to manager main page");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            constraint.gridwidth = 2;
            managerCheckCustomerPanel.add(backToManagerFrame, constraint);
            backToManagerFrame.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    ManagerFrame managerFrame = new ManagerFrame();

                    managerFrame.setTitle( "Welcome to my Fancy ATM" );
                    managerFrame.setSize( 500, 500 );
                    managerFrame.setLocation( 200, 200 );
                    managerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    managerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            add(managerCheckCustomerPanel);
        }
    }

    class ManagerViewTransactionReport extends JFrame {

        private JPanel managerViewTransactionPanel;
        private JScrollPane scrollPane;
        private JButton backToManagerFrame;
        private int yGrid;

        public ManagerViewTransactionReport() throws HeadlessException {

            yGrid = 0;

            managerViewTransactionPanel = new JPanel(new GridBagLayout());
            GridBagConstraints constraint = new GridBagConstraints();

            scrollPane = new JScrollPane();
            managerViewTransactionPanel.add(scrollPane);

            List<String> historys = manager.getTransactionHistory();

            for (String history : historys) {
                constraint.gridy = yGrid++;
                managerViewTransactionPanel.add(new JLabel(history), constraint);
            }

            backToManagerFrame = new JButton("Back to manager main page");
            constraint.gridx = 0;
            constraint.gridy = yGrid++;
            managerViewTransactionPanel.add(backToManagerFrame, constraint);
            backToManagerFrame.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    ManagerFrame managerFrame = new ManagerFrame();

                    managerFrame.setTitle( "Welcome to my Fancy ATM" );
                    managerFrame.setSize( 500, 500 );
                    managerFrame.setLocation( 200, 200 );
                    managerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                    managerFrame.setVisible(true);
                    setVisible(false);
                }
            });

            manager.clearTransactionHistory();

            add(managerViewTransactionPanel);
        }
    }

    class NewCustomerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            CustomerSignUp customerSignUp = new CustomerSignUp();

            customerSignUp.setTitle( "Welcome to my Fancy ATM" );
            customerSignUp.setSize( 500, 500 );
            customerSignUp.setLocation( 200, 200 );
            customerSignUp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            customerSignUp.setVisible(true);
            welcomeFrame.setVisible(false);
        }
    }

    class OldCustomerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            CustomerLogIn customerLogIn = new CustomerLogIn();

            customerLogIn.setTitle( "Welcome to my Fancy ATM" );
            customerLogIn.setSize( 500, 500 );
            customerLogIn.setLocation( 200, 200 );
            customerLogIn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            customerLogIn.setVisible(true);
            welcomeFrame.setVisible(false);
        }
    }

    class ManagerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            ManagerLogInFrame managerLogInFrame = new ManagerLogInFrame();

            managerLogInFrame.setTitle( "Welcome to my Fancy ATM" );
            managerLogInFrame.setSize( 500, 500 );
            managerLogInFrame.setLocation( 200, 200 );
            managerLogInFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            managerLogInFrame.setVisible(true);
            welcomeFrame.setVisible(false);
        }
    }

    private boolean isEmailUnique(String email) {
        for (BankCustomer customer : customerList) {
            if (customer.getEmail().equals(email)) {
                return false;
            }
        }
        return true;
    }

    private boolean authenticateLogIn(String email, String pwd) {
        for (BankCustomer customer : customerList) {
            if (customer.getEmail().equals(email) && customer.getPwd().equals(pwd)) {
                return true;
            }
        }
        return false;
    }

    private String createRandomAccountNum(){
        Random ran = new Random();
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            str.append(ran.nextInt(10));
        }
        return str.toString();
    }

    private boolean isUniqueAccountNum(String accountNum) {
        for (BankCustomer customer : customerList) {
            List<String> allAccountNum = customer.getAllBankAccountNum();
            for (String accountNumber : allAccountNum) {
                if (accountNumber.equals(accountNum)) return false;
            }
        }
        return true;
    }

    private String[] getAccountTypeAndNum (List<BankAccount> accountList) {
        String[] res = new String[accountList.size()];
        for (int i = 0; i < accountList.size(); i++) {
            String str = accountList.get(i).getAccountType() + " " + accountList.get(i).getAccountNum();
            res[i] = str;
        }
        return res;
    }

    private boolean isValidInputAmount(String input) {
        String[] str = input.split("\\.");
        if (str.length > 2) return false;
        if (str.length == 1) {
            try {
                Integer.parseInt(str[0]);
            } catch (Exception e) {
                return false;
            }
            return true;
        } else {
            try {
                Integer.parseInt(str[0]);
                Integer.parseInt(str[1]);
            } catch (Exception e) {
                return false;
            }
            return str[1].length() <= 2;
        }
    }

    private BankCustomer findCustomer(String email){
        for (BankCustomer customer : customerList) {
            if (customer.getEmail().equals(email)) return customer;
        }
        return null;
    }

    private String[] getEmailAndAccountNum() {
        List<String> str = new ArrayList<>();
        for (BankCustomer customer : customerList) {
            List<String> accountNums = customer.getAllCheckingAccountNum();
            if (!accountNums.equals(new ArrayList<>())) {
                for (String accountNum : accountNums) {
                    str.add(customer.getEmail() + " " + accountNum);
                }
            }
        }
        String[] res = new String[str.size()];
        for (int i = 0; i < str.size(); i++) {
            res[i] = str.get(i);
        }
        return res;
    }

    private String[] getCheckingAccountList(List<BankAccount> accounts) {
        List<String> str = new ArrayList<>();
        for (BankAccount account : accounts) {
            if (account.getAccountType().equals("CheckingAccont")) {
                str.add(account.getAccountType() + " " + account.getAccountNum());
            }
        }
        String[] res = new String[str.size()];
        for (int i = 0; i < str.size(); i++) {
            res[i] = str.get(i);
        }
        return res;
    }

    private String[] getAllCustomerEmail() {
        String[] res = new String[customerList.size()];
        for (int i = 0; i < customerList.size(); i++) {
            res[i] = customerList.get(i).getEmail();
        }
        return res;
    }

    private void managerPaySavingInterest() {
        for (BankCustomer customer : customerList) {
            List<BankAccount> accountList = customer.getSavingAccountList();
            for (BankAccount account : accountList) {
                HashMap<String, Double> deposit = account.getDeposit();
                for (Map.Entry<String, Double> entry : deposit.entrySet()) {
                    double balance = entry.getValue();
                    if (balance > SAVING_INTEREST_THRESHOLD) {
                        double newBalance = balance + (balance * SAVING_INTEREST_RATE);
                        deposit.put(entry.getKey(), newBalance);
                    }
                }
            }
        }
    }

    private void managerChargeLoanInterest() {
        for (BankCustomer customer : customerList) {
            List<BankAccount> accountList = customer.getBankAccountOnLoan();
            for (BankAccount account : accountList) {
                HashMap<String, Double> loan = account.getLoan();
                for (Map.Entry<String, Double> entry : loan.entrySet()) {
                    double prevLoan = entry.getValue();
                    double curLoan = prevLoan + (prevLoan * LOAN_INTEREST_RATE);
                    loan.put(entry.getKey(), curLoan);
                }
            }
        }
    }
}
