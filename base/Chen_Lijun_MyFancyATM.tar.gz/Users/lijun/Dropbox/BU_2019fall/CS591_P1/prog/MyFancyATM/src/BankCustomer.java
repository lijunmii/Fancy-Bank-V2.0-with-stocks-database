import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankCustomer {

    private String email;

    private String pwd;

    private List<BankAccount> bankAccountList;

    private BankTransactionHistory transactionHistory;

    public BankCustomer(String customerEmail, String customerPwd) {
        email = customerEmail;
        pwd = customerPwd;
        bankAccountList = new ArrayList<>();
        transactionHistory = new BankTransactionHistory();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public BankAccount getBankAccount(String accountNum) {
        for (BankAccount account : bankAccountList) {
            if (account.getAccountNum().equals(accountNum)) return account;
        }
        return new BankAccount("Error", "Error");
    }

    public List<BankAccount> getBankAccountList() {
        return bankAccountList;
    }

    public List<String> getAllBankAccountNum() {
        List<String> res = new ArrayList<>();
        for (BankAccount account : bankAccountList) {
            res.add(account.getAccountNum());
        }
        return res;
    }

    public List<BankAccount> getBankAccountOnLoan() {
        List<BankAccount> res = new ArrayList<>();
        for (BankAccount account : bankAccountList) {
            if (account.getLoanStatus()) res.add(account);
        }
        return res;
    }

    public List<String> getAllCheckingAccountNum() {
        List<String> res = new ArrayList<>();
        for (BankAccount account : bankAccountList) {
            if (account.getAccountType().equals("CheckingAccount")) res.add(account.getAccountNum());
        }
        return res;
    }

    public List<BankAccount> getSavingAccountList() {
        List<BankAccount> res = new ArrayList<>();
        for (BankAccount account : bankAccountList) {
            if (account.getAccountType().equals("SavingAccount")) res.add(account);
        }
        return res;
    }

    public void setBankAccountList(List<BankAccount> bankAccountList) {
        this.bankAccountList = bankAccountList;
    }

    public void addBankAccount(BankAccount account) {
        bankAccountList.add(account);
    }

    public void removeBankAccount(BankAccount account) {
        bankAccountList.remove(account);
    }

    public void updateBankAccountDeposit(BankAccount account, String currency, double amount) {
        account.updateDeposit(currency, amount);
    }

    public double getBankAccountDepositCurrencyBalance(BankAccount account, String currency) {
        return account.getDepositCurrencyBalance(currency);
    }

    public boolean isAccountEmpty(BankAccount account) {
        HashMap<String, Double> balance = account.getDeposit();
        for (Map.Entry<String, Double> entry : balance.entrySet()) {
            if (entry.getValue() != 0.0) return false;
        }
        return true;
    }

    public void updateBankAccountLoan(BankAccount account, String currency, double amount) {
        account.updateLoan(currency, amount);
    }

    public double getBankAccountLoanCurrencyBalance(BankAccount account, String currency) {
        return account.getLoanCurrencyBalance(currency);
    }

    public List<String> getTransactionHistory() {
        return transactionHistory.getHistory();
    }

    public void setTransactionHistory(BankTransactionHistory transactionHistory) {
        this.transactionHistory = transactionHistory;
    }

    public void updataTransactionHistory(String newTransaction) {
        this.transactionHistory.addHistory(newTransaction);
    }
}
