import java.util.HashMap;
import java.util.Map;

public class BankAccount {

    private String accountNum;

    private String accountType;

    private boolean loanStatus;

    private HashMap<String, Double> deposit;

    private HashMap<String, Double> loan;

    public BankAccount(String accountNum, String accountType) {
        this.accountNum = accountNum;
        this.accountType = accountType;
        deposit = new HashMap<>();
        deposit.put("Dollor", 0.0);
        deposit.put("Yuan", 0.0);
        deposit.put("Pound", 0.0);
        loan = new HashMap<>();
        loan.put("Dollor", 0.0);
        loan.put("Yuan", 0.0);
        loan.put("Pound", 0.0);
        loanStatus = false;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public HashMap<String, Double> getDeposit() {
        return deposit;
    }

    public void setDeposit(HashMap<String, Double> deposit) {
        this.deposit = deposit;
    }

    public void updateDeposit(String currency, double amount) {
        double currentAmount = deposit.get(currency);
        deposit.put(currency, currentAmount + amount);
    }

    public double getDepositCurrencyBalance(String currency) {
        return deposit.get(currency);
    }

    public HashMap<String, Double> getLoan() {
        return loan;
    }

    public void setLoan(HashMap<String, Double> loan) {
        this.loan = loan;
    }

    public void updateLoan(String currency, double amount) {
        double currentAmount = loan.get(currency);
        loan.put(currency, currentAmount + amount);
        updateLoanStatus();
    }

    public double getLoanCurrencyBalance(String currency) {
        return loan.get(currency);
    }

    public void updateLoanStatus() {
        for (Map.Entry<String, Double> entry : loan.entrySet()) {
            if (entry.getValue() != 0.0) loanStatus = true;
        }
    }

    public boolean getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(boolean loanStatus) {
        this.loanStatus = loanStatus;
    }
}
