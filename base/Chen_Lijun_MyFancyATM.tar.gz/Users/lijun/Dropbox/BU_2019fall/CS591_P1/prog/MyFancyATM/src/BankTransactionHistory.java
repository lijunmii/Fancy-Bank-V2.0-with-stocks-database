import java.util.ArrayList;
import java.util.List;

public class BankTransactionHistory {

    List<String> history;

    public BankTransactionHistory() {
        history = new ArrayList<>();
    }

    public List<String> getHistory() {
        return history;
    }

    public void setHistory(List<String> transactionHistory) {
        history = transactionHistory;
    }

    public void addHistory(String newTransaction) {
        history.add(newTransaction);
    }

    public void clearHistory() {
        history = new ArrayList<>();
    }
}
