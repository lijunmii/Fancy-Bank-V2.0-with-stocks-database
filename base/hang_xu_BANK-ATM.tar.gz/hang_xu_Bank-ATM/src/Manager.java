/**
 * @author Hang Xu
 * @date Fall 2019
 */
public class Manager extends AbstractPerson {
    public Manager(Name name, long phoneNumber) {
        super(name, phoneNumber,true);
    }
}
